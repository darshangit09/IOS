/*0func isPrime(_ number: Int) -> Bool {
    for i in 2..<number {
        if number % i == 0 {
            return false
        }
    }
    return true
}

// Example usage
let num = 29
if isPrime(num) {
    print("\(num) is a prime number")
} else {
    print("\(num) is not a prime number")
}
*/

func isPalindrome(_ word: String) -> Bool {
    let characters = Array(word.lowercased())
    var startIndex = 0
    var endIndex = characters.count - 1
    
    while startIndex < endIndex {
        if characters[startIndex] != characters[endIndex] {
            return false
        }
        startIndex += 1
        endIndex -= 1
    }
    
    return true
}

// Example usage
let word = "racecar"
if isPalindrome(word) {
    print("\(word) is a palindrome")
} else {
    print("\(word) is not a palindrome")
}
